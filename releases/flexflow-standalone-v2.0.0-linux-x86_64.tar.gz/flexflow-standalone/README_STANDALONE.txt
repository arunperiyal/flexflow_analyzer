FlexFlow Standalone Executable - Version 2.0.0
=================================================

This is a standalone version of FlexFlow that includes:
- Python 3.12 interpreter (embedded)
- All Python dependencies
- FlexFlow application code

NO PYTHON INSTALLATION REQUIRED!
NO CONDA ACTIVATION NEEDED!

Requirements:
- Linux x86_64
- Tecplot 360 installed at: /usr/local/tecplot/360ex_2024r1/

Usage:
  ./flexflow <command> [options]

Examples:
  ./flexflow --version          # or -v (show version)
  ./flexflow case show CS4SG1U1
  ./flexflow field info CS4SG1U1
  ./flexflow plot CS4SG1U1 --node 10 --component y

Works with ANY system Python version (3.13, 3.14, doesn't matter!)

Size: 71 MB
Version: 2.0.0
Python Version: 3.12.12 (embedded)
Build Date: 2026-01-06

For documentation: See PYTECPLOT_GUIDE.md and README.md
